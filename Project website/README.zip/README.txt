Virtual Assistant
This is a Python-based Virtual Assistant that can interact with users through text or speech. It can provide weather updates, deliver the latest news, and respond to general inquiries.

Features
-Text-Based Interaction: Communicate with the assistant through text input.
-Speech-Based Interaction: Communicate with the assistant through voice commands.
-Weather Information: Retrieve current weather data for a specified city.
-News Headlines: Get the latest top 5 news headlines.
-Jokes: Receive a random joke.
-Quotes: Get a motivational quote.
-Current Time and Date: Retrieve the current time and date.
-Help and Information: Get information about the assistant and available commands.

Requirements
-Python 3.x
-The following Python libraries:
 -speech_recognition
 -pyttsx3
 -requests
 -nltk

Installation

1.Install Required Packages:
Install the required Python packages using pip:
--------------------------------------------------------------------------------------------
pip install speechrecognition pyttsx3 requests nltk
--------------------------------------------------------------------------------------------

2.Download NLTK Data:
The assistant uses NLTK for text processing. Ensure you have the necessary datasets by running:
--------------------------------------------------------------------------------------------
import nltk
nltk.download('punkt')
nltk.download('stopwords')
--------------------------------------------------------------------------------------------

3.Configure API Keys:
-Weather API: Get an API key from OpenWeatherMap.
-News API: Get an API key from NewsAPI.
Replace the placeholder API keys in the code with your own.

Usage
1.Run the Virtual Assistant:
--------------------------------------------------------------------------------------------
python main_project.py
--------------------------------------------------------------------------------------------

You will be prompted to choose between text or speech interaction.

Commands and Responses

Text Interaction
When interacting via text, you can enter the following commands:

-Greeting Commands:
 -"hello" or "hi" - The assistant will greet you.
 -"your name" - The assistant will tell you its name.
 -"bye" or "goodbye" - The assistant will say goodbye and end the session.

-Information Requests:
 -"news" - Get the latest top 5 news headlines.
 -"weather" - Get the weather information for a specified city.
 -"joke" - Receive a random joke.
 -"quote" - Get a motivational quote.
 -"time" - Get the current time.
 -"date" - Get the current date.
 -"who are you" - Learn about the assistant.

Help Command:
 -"help" - Get a list of available commands and how to use them.

Speech Interaction
When interacting via speech, you can say the following commands:

-Greeting Commands:
 -"hello" or "hi" - The assistant will greet you.
 -"your name" - The assistant will tell you its name.
 -"bye" or "goodbye" - The assistant will say goodbye and end the session.

Information Requests:
 -"news" - Get the latest top 5 news headlines.
 -"weather" - The assistant will ask for the city and provide the weather information.
 -"joke" - Receive a random joke.
 -"quote" - Get a motivational quote.
 -"time" - Get the current time.
 -"date" - Get the current date.
 -"who are you" - Learn about the assistant.

Help Command:
 -"help" - Get a list of available commands and how to use them.

Customization Command:
-change voice – Change the voice used by the assistant.
-change speed – Adjust the speech rate.
-change volume – Modify the volume level.
-change language – Switch the language for speech recognition and responses.

Configuration
-API Keys:
 -Replace the placeholder API keys in the reaction and weather_reaction functions with your own API keys from NewsAPI and OpenWeatherMap.

Customization

-Change Voice
 To change the voice, type or say change voice and choose from the available voice options.
-Change Speech Rate
 To adjust the speech rate, type or say change speed and enter the desired rate.
-Change Volume
 To modify the volume, type or say change volume and specify a value between 0.0 and 1.0.
-Change Language
 To switch the language, type or say change language and provide a valid language code.

Example
--------------------------------------------------------------------------------------------
Virtual Assistant is running...
Hello, would you rather use text or speech to interact with me? text
Please enter your text (or type 'back' to return to the main menu): what's the weather in New York?
Assistant: Temperature: 25°C
Humidity: 60%
Pressure: 1013 hPa
Wind Speed: 5 m/s
Weather Description: clear sky
--------------------------------------------------------------------------------------------

Error Handling
The assistant includes robust error handling to manage issues such as:
-Network connectivity problems.
-Invalid API responses.
-Unrecognized speech inputs.
