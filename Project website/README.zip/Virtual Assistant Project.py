import speech_recognition as sr
import pyttsx3
import requests
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from datetime import datetime

# Initialize speech recognition and text-to-speech engines
r = sr.Recognizer()
tts_engine = pyttsx3.init()

# Settings dictionary
settings = {
    'voice': 1,  # Default voice index
    'rate': 150, # Default speech rate
    'volume': 0.5, # Default volume level
    'language': 'en-UK' # Default language code
}

def update_tts_engine():
    """Update the TTS engine settings based on user preferences."""
    voices = tts_engine.getProperty('voices')
    tts_engine.setProperty('voice', voices[settings['voice']].id)
    tts_engine.setProperty('rate', settings['rate'])
    tts_engine.setProperty('volume', settings['volume'])

def text_to_speech(text):
    """Convert the given text to speech."""
    try:
        update_tts_engine()  # Apply the current settings
        tts_engine.say(text)
        tts_engine.runAndWait()
    except Exception as e:
        print(f"An error occurred during text-to-speech: {e}")

def receive_speech():
    """Listen to the user's speech and return the recognized text."""
    print("Listening...")
    try:
        with sr.Microphone() as source:
            r.adjust_for_ambient_noise(source)
            audio = r.listen(source)
            try:
                text = r.recognize_google(audio, language=settings['language'])
                print(f"Recognized text: {text}")
                return text
            except sr.UnknownValueError:
                print("Sorry, I didn't catch that. Could you repeat?")
            except sr.RequestError as e:
                print(f"Could not request results from Google Speech Recognition service; {e}")
    except Exception as e:
        print(f"An unexpected error occurred while listening: {e}")
    return None

def get_weather(api_key, city_name):
    """Fetch and return weather information for a given city."""
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}&units=metric"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        if "main" in data:
            main = data['main']
            wind = data['wind']
            weather_description = data['weather'][0]['description']
            weather_info = (f"Temperature: {main['temp']}°C\n"
                            f"Humidity: {main['humidity']}%\n"
                            f"Pressure: {main['pressure']} hPa\n"
                            f"Wind Speed: {wind['speed']} m/s\n"
                            f"Weather Description: {weather_description}")
            return weather_info
        else:
            return "Unexpected response format. Please try again later."
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        return "City not found or invalid API key."
    except requests.exceptions.ConnectionError:
        print("Failed to connect to the weather service. Please check your internet connection.")
        return "Unable to connect to the weather service."
    except requests.exceptions.Timeout:
        print("The request to the weather service timed out.")
        return "The weather service is taking too long to respond. Please try again later."
    except requests.exceptions.RequestException as req_err:
        print(f"An error occurred while requesting weather data: {req_err}")
        return "An error occurred while fetching the weather information."
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return "An unexpected error occurred. Please try again later."

def get_news(api_key):
    """Fetch and return the top 5 news headlines."""
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={api_key}"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        if "articles" in data:
            articles = data['articles']
            news = ""
            for article in articles[:5]:
                news += f"Title: {article['title']}\nDescription: {article['description']}\n\n"
            return news
        else:
            return "Unexpected response format. Please try again later."
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        return "Unable to fetch news or invalid API key."
    except requests.exceptions.ConnectionError:
        print("Failed to connect to the news service. Please check your internet connection.")
        return "Unable to connect to the news service."
    except requests.exceptions.Timeout:
        print("The request to the news service timed out.")
        return "The news service is taking too long to respond. Please try again later."
    except requests.exceptions.RequestException as req_err:
        print(f"An error occurred while requesting news data: {req_err}")
        return "An error occurred while fetching the news."
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return "An unexpected error occurred. Please try again later."

def process_text(text):
    """Process the input text by tokenizing and removing stop words."""
    text = text.lower()
    tokens = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word not in stop_words]
    return filtered_tokens

def reaction(text):
    """Generate a response based on the input text."""
    news_api_key = "78f541f419d84eb889a5b7489a1c0047"
    
    text = text.lower()

    if 'hello' in text or 'hi' in text:
        return "Hello! How can I assist you today?"
    elif 'assistant' in text:
        return "What can I help you with?"
    elif 'your name' in text:
        return "My name is Assistant."
    elif 'bye' in text or 'goodbye' in text:
        return "Goodbye! Have a great day!"
    elif 'news' in text:
        return get_news(news_api_key)
    elif 'joke' in text:
        return "What do you call a Star Wars droid that takes the long way around? R2 detour."
    elif 'quote' in text:
        return "Here's a motivational quote for you: 'The only way to do great work is to love what you do.' - Steve Jobs"
    elif 'time' in text:
        now = datetime.now()
        return f"The current time is {now.strftime('%H:%M:%S')}."
    elif 'date' in text:
        today = datetime.today()
        return f"Today's date is {today.strftime('%Y-%m-%d')}."
    elif 'who are you' in text:
        return "I am a virtual assistant programmed to help with various tasks."
    elif 'help' in text:
        return "Here are some things you can ask me: 'news', 'weather', 'joke', 'quote', 'time', 'date'."
    elif 'change voice' in text:
        return change_voice()
    elif 'change speed' in text:
        return change_speed()
    elif 'change volume' in text:
        return change_volume()
    elif 'change language' in text:
        return change_language()
    else:
        return "Sorry, I didn't understand that. Can you please rephrase?"

def weather_reaction(api_key, text, city_name):
    """Respond with weather information if the input text asks for it."""
    if 'weather' in text:
        return get_weather(api_key, city_name)

def change_voice():
    """Change the voice setting."""
    global settings
    voices = tts_engine.getProperty('voices')
    print("Available voices:")
    for i, voice in enumerate(voices):
        print(f"{i}: {voice.name}")
    choice = input("Enter the number of the voice you want to use: ")
    try:
        settings['voice'] = int(choice)
        update_tts_engine()
        return f"Voice changed to {voices[settings['voice']].name}."
    except (ValueError, IndexError):
        return "Invalid choice. Please select a valid voice number."

def change_speed():
    """Change the speech rate."""
    global settings
    rate = input("Enter the new speech rate (e.g., 150): ")
    try:
        settings['rate'] = int(rate)
        update_tts_engine()
        return f"Speech rate changed to {settings['rate']}."
    except ValueError:
        return "Invalid rate. Please enter a numeric value."

def change_volume():
    """Change the volume level."""
    global settings
    volume = input("Enter the new volume level (0.0 to 1.0): ")
    try:
        volume = float(volume)
        if 0.0 <= volume <= 1.0:
            settings['volume'] = volume
            update_tts_engine()
            return f"Volume level changed to {settings['volume']}."
        else:
            return "Volume must be between 0.0 and 1.0."
    except ValueError:
        return "Invalid volume. Please enter a numeric value between 0.0 and 1.0."

def change_language():
    """Change the language setting."""
    global settings
    language = input("Enter the new language code (e.g., 'en-GB'): ")
    # Validate language code with available options
    if language in ['en-GB', 'en-US', 'es-ES', 'fr-FR', 'de-DE']:  # Add more valid codes as needed
        settings['language'] = language
        return f"Language changed to {settings['language']}."
    else:
        return "Invalid language code. Please enter a valid language code."

def text():
    """Handle text-based interaction with the assistant."""
    api_key = "83c9ab29ae1b3e085a11b443028b6c7d"
    while True:
        user_input = input("Please enter your text (or type 'back' to return to the main menu): ").lower()
        if user_input == 'back':
            break
        if user_input:
            tokens = process_text(user_input)
            if 'weather' in tokens:
                city_name = input("What city's weather do you want to check? ")
                response = weather_reaction(api_key, user_input, city_name)
            else:
                response = reaction(user_input)
            print(f"Assistant: {response}")
            text_to_speech(response)
            if 'bye' in user_input or 'goodbye' in user_input:
                break

def speech():
    """Handle speech-based interaction with the assistant."""
    api_key = "83c9ab29ae1b3e085a11b443028b6c7d"
    while True:
        print("Please say something (or say 'back' to return to the main menu):")
        user_input = receive_speech()
        if user_input == 'back':
            break
        if user_input:
            tokens = process_text(user_input)
            if 'weather' in tokens:
                print("What city's weather do you want to check?")
                city_name = receive_speech()
                response = weather_reaction(api_key, user_input, city_name)
            else:
                response = reaction(user_input)
            print(f"Assistant: {response}")
            text_to_speech(response)
            if 'bye' in user_input or 'goodbye' in user_input:
                break

def main():
    """Main function to start the virtual assistant."""
    while True:
        print("Virtual Assistant is running...")
        choice = input("Hello, would you rather use text or speech to interact with me? ").lower()
        if choice == "text":
            text()
        elif choice == "speech":
            speech()
        elif choice == 'exit':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please type 'text', 'speech', or 'exit'.")

if __name__ == "__main__":
    main()
